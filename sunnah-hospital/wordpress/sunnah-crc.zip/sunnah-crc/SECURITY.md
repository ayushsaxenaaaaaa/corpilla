# Security – what the theme does and what the site owner must do

No theme alone can make a website "100% safe". Most WordPress sites are hacked through weak passwords,
outdated plugins or insecure hosting, not through the theme. This theme is written to WordPress security
standards, and the checklist below covers the rest.

## Built into the theme
- All output is escaped and all input is sanitised; every PHP file refuses direct access.
- The enquiry form uses a WordPress security token (nonce), a hidden spam trap, a signed time stamp
  (forms sent within 3 seconds, older than 2 days or with a forged stamp are refused), a link filter (messages with
  several web links are dropped), rate limits (5 per visitor per 10 minutes, 15 per visitor per day, 60 per hour for
  the whole site), input length limits and safe email headers.
  Per-visitor limits use the visitor's real IP (also behind Cloudflare, see step 9); IPv6 visitors are grouped by
  their /64 network so a bot cannot dodge the limit by changing addresses.
  The rate-limit counters are increased with one atomic database statement, so simultaneous requests cannot slip past
  the limit (tested: 40 requests at the same instant from one visitor → exactly 5 accepted; 100 visitors at once →
  exactly 60). The tests can be re-run from `tools/tests/` in the project repository (not included in the theme zip).
  Old counters are removed by a daily WordPress task. For protection against large floods, still use
  Cloudflare rate limiting (step 9): it stops traffic before it reaches the server.
- Server-side validation: department and preferred time must be one of the form's own options (any other value
  rejects the whole submission); the preferred date
  must be a real date from today up to one year ahead; the contact number must have 10–13 digits.
- **Content Security Policy (CSP)** header: browsers only load scripts, styles, fonts and frames from the site itself,
  Google Fonts, Google Maps and YouTube. Plugins needing another source can add it with the `sunnah_crc_csp_sources` filter.
  - Enforced policy: still allows inline scripts, because some plugins add them.
  - A **stricter policy (no inline scripts) is sent in Report-Only mode** at the same time: it blocks nothing, but the
    browser console (F12 → Console) lists anything it would block. The theme itself needs no inline scripts (the
    WordPress emoji script is switched off for this).
  - After the final plugins are installed, open the main pages with F12 open. If no "Content-Security-Policy-Report-Only"
    messages appear, switch the strict policy on by adding this line to a small site plugin or wp-config-loaded mu-plugin:
    `add_filter( 'sunnah_crc_csp_strict', '__return_true' );`
- **Doctor profiles have their own permissions**: only Administrators and Editors can add, edit or delete doctors.
  Authors, Contributors and Subscribers cannot (the same rules apply in the editor and through the REST API).
- No file uploads, no database writes from visitors, no third-party scripts except Google Fonts.
- XML-RPC is turned off (a common target for password-guessing attacks).
- **REST API closed to the public.** WordPress normally exposes a data interface at `/wp-json/` (the "REST API").
  The public website does not use it, so the theme refuses every REST request from visitors who are not logged in
  (they get "401 – not available"). Logged-in staff keep access because the WordPress editor needs it.
  The REST, shortlink and oEmbed discovery links are removed from every page, application passwords
  (API logins from outside the site) are switched off, and `robots.txt` disallows `/wp-json/`.
  The enquiry form does not use the REST API; it is a normal form post with a security token.
- Comments and pingbacks are switched off everywhere (they attract spam and links).
- Code editing from the WordPress admin is switched off (`DISALLOW_FILE_EDIT`), so a stolen login cannot edit PHP.
- The WordPress version number is hidden.
- Visitors cannot list usernames through `?author=` links, author pages, the REST API or the sitemap.
- Login errors don't reveal whether the username or the password was wrong.
- Security headers: X-Content-Type-Options, X-Frame-Options (stops the site being embedded by others),
  Referrer-Policy, Permissions-Policy.
- `robots.txt` keeps search engines out of `/wp-admin/` and the login page.
- Empty `index.php` files stop folder contents being listed; like every other PHP file, they refuse direct execution.

## Must be done on the live site (by whoever manages hosting)
These cannot be done inside a theme. Summary: **two-factor login** (step 3), **Cloudflare / firewall** (step 9) and
**off-server backups** (step 5).

1. **HTTPS**: install an SSL certificate (free with most hosts) and set both WordPress Address and Site Address to `https://`.
2. **Strong admin accounts**: no username "admin"; long unique passwords; give staff "Editor" role, not "Administrator".
3. **Two-factor login and login limits**: install one well-known security plugin, e.g. **Wordfence** or **Solid Security**,
   and turn on two-factor authentication and login attempt limits.
4. **Updates**: keep WordPress core, plugins and PHP (8.1 or newer) updated. Remove unused plugins and themes.
5. **Backups**: daily automatic backups stored off the server (e.g. **UpdraftPlus** to Google Drive), and test a restore once.
6. **wp-config.php**: add
   ```php
   define( 'DISALLOW_FILE_EDIT', true );   // no code editing from the admin
   define( 'WP_DEBUG', false );
   ```
   and use the unique security keys from https://api.wordpress.org/secret-key/1.1/salt/
7. **File permissions**: folders 755, files 644, `wp-config.php` 600 or 640.
8. **Email**: use an SMTP plugin with the hospital's email account so enquiries are delivered reliably.
9. **Protection against attacks that try to bring the site down (DDoS / floods)**: this cannot be done by a theme,
   because the traffic arrives before WordPress runs. Put the site behind **Cloudflare** (the free plan is enough):
   - point the domain's nameservers to Cloudflare and turn on the orange-cloud proxy for the website records;
   - SSL/TLS mode **Full (strict)**; "Always Use HTTPS" on;
   - Security → Bots: **Bot Fight Mode** on; Security level "Medium";
   - a free **rate-limiting rule**: more than 10 requests in 10 seconds to `/wp-login.php` or `/wp-admin/admin-post.php` → block for 10 minutes;
   - **Under Attack Mode** can be switched on with one click if the site is ever flooded.
   - **Real visitor IP behind Cloudflare.** With the proxy on, the server sees Cloudflare's address instead of the
     patient's. The theme already handles this safely: it uses the `CF-Connecting-IP` header **only** when the
     connection really comes from one of Cloudflare's official address ranges, so the header cannot be faked
     (check the list in `sunnah_crc_cloudflare_ranges()` against https://www.cloudflare.com/ips/ once a year).
     Recommended as well, so server logs and security plugins also see real IPs: restore the IP in the web server.
     Nginx (`http` block), with one `set_real_ip_from` line per range listed on https://www.cloudflare.com/ips/:
     ```nginx
     set_real_ip_from 173.245.48.0/20;   # ...repeat for every Cloudflare IPv4 and IPv6 range
     real_ip_header CF-Connecting-IP;
     ```
     Apache: enable `mod_remoteip` with `RemoteIPHeader CF-Connecting-IP` and `RemoteIPTrustedProxy` for each range.
     Many hosts (cPanel, Cloudways, Hostinger) do this automatically when Cloudflare is connected from their panel.
   Also turn on Wordfence's **Rate Limiting** and **Brute Force Protection**, and choose a host with server-level
   firewall and DDoS protection. Cloudflare also caches pages, which keeps the site fast under heavy traffic.
10. **Privacy**: publish the Privacy Policy page. The form asks visitors not to send medical reports;
   enquiries are only emailed, not stored on the website.
